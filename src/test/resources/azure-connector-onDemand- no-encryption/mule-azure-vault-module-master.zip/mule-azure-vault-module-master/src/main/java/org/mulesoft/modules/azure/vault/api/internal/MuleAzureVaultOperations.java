package org.mulesoft.modules.azure.vault.api.internal;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;

import com.microsoft.aad.adal4j.AuthenticationException;
import com.microsoft.azure.PagedList;
import com.microsoft.azure.keyvault.SecretIdentifier;
import com.microsoft.azure.keyvault.models.SecretBundle;
import com.microsoft.azure.keyvault.models.SecretItem;
import org.mule.runtime.extension.api.annotation.metadata.OutputResolver;
import org.mule.runtime.extension.api.annotation.param.MediaType;
import org.mule.runtime.extension.api.annotation.param.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.authentication.KeyVaultCredentials;
import org.mule.runtime.extension.api.annotation.param.display.DisplayName;

import java.util.HashMap;
import java.util.Map;


/**
 * This class is a container for operations, every public method in this class will be taken as an extension operation.
 */
public class MuleAzureVaultOperations {


  protected static final Logger LOGGER = LoggerFactory.getLogger(MuleAzureVaultOperations.class);
  protected static final String AZURE_VAULT_DOMAIN = ".vault.azure.net";

  @MediaType(value =  "*/*", strict = false)
  @DisplayName("Get Single Key from vault")
  public String getSecret(@Config MuleAzureVaultConfiguration configuration, String vaultName, String key){

    String vaultUrl = "https://"+ vaultName + AZURE_VAULT_DOMAIN;
    String applicationClientId=configuration.getAzureApplicationClientId();
    String applicationSecretKey= configuration.getAzureApplicationSecretKey();
    String secretValue = "";


    try {
      KeyVaultCredentials kvCred = fetchKeyVaultCredentials(applicationClientId, applicationSecretKey);
      KeyVaultClient kvClient = new KeyVaultClient(kvCred);
      SecretBundle secret = kvClient.getSecret(vaultUrl, key);

      if (secret != null) {
        secretValue = secret.value();
      } else {
        LOGGER.error("secret key not found : " + key);

      }

    }catch(AuthenticationException ae){
      System.out.println("exception while getting the accesstoken" + ae.getMessage());
    }

    catch (Exception e){


          System.out.println("Error Occured " + e.getMessage());

    }
    return secretValue;
  }
  @DisplayName("Get All Key Value from Vault")
  @OutputResolver(output = OutputEntityResolver.class)
  public Map<String, String> getAllSecrets(@Config MuleAzureVaultConfiguration configuration, String vaultName){

    String vaultUrl = "https://"+ vaultName + AZURE_VAULT_DOMAIN;
    String applicationClientId=configuration.getAzureApplicationClientId();
    String applicationSecretKey= configuration.getAzureApplicationSecretKey();

    Map<String,String> hashMap = new HashMap<>();

try {
  KeyVaultCredentials kvCred = fetchKeyVaultCredentials(applicationClientId, applicationSecretKey);
  KeyVaultClient kvClient = new KeyVaultClient(kvCred);
  PagedList<SecretItem> secretItemList = kvClient.getSecrets(vaultUrl);
  for (final SecretItem secretItem : secretItemList) {
    SecretIdentifier secretIdentifier = new SecretIdentifier(secretItem.id());
    SecretBundle secretBundle = kvClient.getSecret(secretIdentifier.identifier());
    String value = secretBundle.value();
    hashMap.put(secretIdentifier.name(), value);

  }
  ;
}
catch(AuthenticationException ae){
  System.out.println("exception while getting the accesstoken" + ae.getMessage());
}

catch (Exception e){

    System.out.println("Error Occured " + e.getMessage());
}

    return hashMap;
  }


  /**
   * Private Methods are not exposed as operations
   */
  private KeyVaultCredentials fetchKeyVaultCredentials(String azureApplicationClientId, String azureApplicationSecretKey ) {
    KeyVaultCredentials kvCred = new MuleAzureVaultClientSecretKeyCredential(azureApplicationClientId,azureApplicationSecretKey);
    return kvCred;
  }
}
