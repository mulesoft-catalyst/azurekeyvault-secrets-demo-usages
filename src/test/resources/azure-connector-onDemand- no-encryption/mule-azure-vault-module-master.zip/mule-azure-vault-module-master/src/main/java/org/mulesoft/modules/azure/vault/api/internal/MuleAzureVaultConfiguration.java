package org.mulesoft.modules.azure.vault.api.internal;

import org.mule.runtime.extension.api.annotation.Operations;
import org.mule.runtime.extension.api.annotation.param.Parameter;
import org.mule.runtime.extension.api.annotation.param.display.Password;
import org.mule.runtime.extension.api.annotation.param.display.Summary;


/**
 * This class represents an extension configuration, values set in this class are commonly used across multiple
 * operations since they represent something core from the extension.
 */
@Operations(MuleAzureVaultOperations.class)
public class MuleAzureVaultConfiguration {



  @Parameter
  @Password
  @Summary("Azure Vault Application Client ID")
  String azureApplicationClientId;

  @Parameter
  @Password
  @Summary("Azure Vault Application Key")
  String azureApplicationSecretKey;



  public String getAzureApplicationClientId() {
    return azureApplicationClientId;
  }

  public void setAzureApplicationClientId(String azureApplicationClientId) {
    this.azureApplicationClientId = azureApplicationClientId;
  }

  public String getAzureApplicationSecretKey() {
    return azureApplicationSecretKey;
  }

  public void setAzureApplicationSecretKey(String azureApplicationSecretKey) {
    this.azureApplicationSecretKey = azureApplicationSecretKey;
  }
}
