# Mule Azure Vault Manager Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>org.mulesoft.modules</groupId>
<artifactId>mule-azure-vault-module</artifactId>
<version>1.0.0</version>
<classifier>mule-plugin</classifier>
```
